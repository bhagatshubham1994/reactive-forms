import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss']
})
export class FormBuilderComponent implements OnInit {

  signUpForm: FormGroup;
  genders = ['male', 'female']
  validationMessages = {
    'username': {
      'required': 'Username is required.',
      'minlength': 'Username must be greater than 2 characters.',
      'maxlength': 'Username must be less than 10 characters.'
    },
    'email': {
      'required': 'Email is required field'
    },
    'gender': {
      'required': 'Gender is required.'
    }
  };

  formErrors = {
    'username': '',
    'email': '',
    'gender': ''
  };

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.signUpForm = this.fb.group({
      'userData': this.fb.group({
        'username': ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
        'email': ['', Validators.required]
      }),
      'gender': ['', Validators.required],
      'hobbies': this.fb.array([])
    })

    this.signUpForm.get('userData.username').valueChanges.subscribe(value => {
      console.log(value)
    });
  
    this.signUpForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.signUpForm);
    })
  }

  addHobby() {
    (<FormArray>this.signUpForm.get('hobbies')).push(new FormControl(''))
  }

  deleteAllHobbies() {
    let hobbies = this.signUpForm.get('hobbies') as FormArray
    hobbies.clear()
  }

  deleteHobby(index: number) {
    (<FormArray>this.signUpForm.get('hobbies')).removeAt(index)
  }

  onSubmit() {
    this.logValidationErrors(this.signUpForm)
    if(this.signUpForm.valid) {

    }
    console.log(this.formErrors);
  }

  logValidationErrors(group: FormGroup = this.signUpForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl)
      } else {
        this.formErrors[key] = '';
        if(abstractControl && abstractControl.invalid && (abstractControl.touched || abstractControl.dirty)) {
          const messages = this.validationMessages[key];
          console.log( messages );
          console.log(  abstractControl.errors );
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }
      }
    })
  }

  clearData() {
    this.signUpForm.reset();
  }

}
